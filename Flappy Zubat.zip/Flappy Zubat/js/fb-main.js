
//Modo de começar o jogo
   var debugmode = false;

   // objeto que "congela" o jogo
   var states = Object.freeze({
      SplashScreen: 0,
      GameScreen: 1,
      ScoreScreen: 2
   });

   var currentstate;
   var gravity = 0.25;
   var velocity = 0;
   var position = 180;
   var rotation = 0;
   var jump = -4.6;
   var score = 0;
   var recorde = 0;
   var pipeheight = 90;
   var pipewidth = 52;
   var pipes = new Array();
   var replayclickable = false;
   var volume = 30;
   var soundJump = new buzz.sound("imagens/sounds/sfx_wing.ogg");
   var soundScore = new buzz.sound("imagens/sounds/sfx_point.ogg");
   var soundHit = new buzz.sound("imagens/sounds/sfx_hit.ogg");
   var soundDie = new buzz.sound("imagens/sounds/sfx_die.ogg");
   var soundSwoosh = new buzz.sound("imagens/sounds/sfx_swooshing.ogg");
   buzz.all().setVolume(volume);
   var loopGame;
   var loopPipe;

   // começando o jogo...
   $(document).ready(function() {
      if(window.location.search == "?debug")
         debugmode = true;
      if(window.location.search == "?easy")
         pipeheight = 200;
      
      // salva o recorde pelo cookie
      var savedscore = getCookie("recorde");
      if(savedscore != "")
         recorde = parseInt(savedscore);
      
      // Tela inicial
      showSplash();
   });

   // Função para capturar o cookie para mostrar os pnts depois
   function getCookie(cname) {
      var name = cname + "=";
      var ca = document.cookie.split(';');
      for(var i=0; i<ca.length; i++){
         var c = ca[i].trim();
         if (c.indexOf(name)==0) return c.substring(name.length,c.length);
      }
      return "";
   }

   // armazena o cookie
   function setCookie(cname,cvalue,exdays) {
      var d = new Date();
      d.setTime(d.getTime()+(exdays*24*60*60*1000));
      var expires = "expires="+d.toGMTString();
      document.cookie = cname + "=" + cvalue + "; " + expires;
   }

   // Função mostrar a tela do início do jogo
   function showSplash() {
      currentstate = states.SplashScreen; // variavel para armazenar o estado do jogo e tratar posteriormente os eventos
      
      // define os valores iniciais
      velocity = 0;
      position = 180;
      rotation = 0;
      score = 0;
      
      // resetar as posições do zubat para o novo jogo
      $("#jogador").css({ y: 0, x: 0});
      updatePlayer($("#jogador"));
      
      soundSwoosh.stop();
      soundSwoosh.play();
      
      // limpar todos os canos para iniciar o novo jogo
      $(".pipe").remove();
      pipes = new Array();
      
      // começar todas as animações dos sprites novamente
      $(".animated").css('animation-play-state', 'running');
      $(".animated").css('-webkit-animation-play-state', 'running');
      
      //splash screen aparece
      $("#splash").transition({ opacity: 1 }, 2000, 'ease');
   }

   function startGame() {
      currentstate = states.GameScreen; // armazena o estado do jogo e tratar posteriormente os eventos

      // fade para a splash screen sumir
      $("#splash").stop();
      $("#splash").transition({ opacity: 0 }, 500, 'ease');
      
      setBigScore();   // mostra os pontos ao longo do jogo
      
      // debug mode para considerar as bordas ao redor
      if(debugmode) {
         $(".boundingbox").show();
      }

      // começar os loops do jogo - aumentar o tempo e intervalo de canos
      var updaterate = 1000.0 / 60.0 ; // 60 fps
      loopGame = setInterval(gameloop, updaterate);
      loopPipe = setInterval(updatePipes, 1400);
      
      // ação de pulo para começar o jogo
      playerJump();
   }

   // Função para aumentar a velocidade e a rotação do zubat
   function updatePlayer(player) {
      // Rotação
      rotation = Math.min((velocity / 10) * 90, 90);
      
      // Aplicando a rotação por css (X,Y)
      $(player).css({ rotate: rotation, top: position });
   }

     function gameloop() {

      var player = $("#jogador");
      
      // Aumentar a posição e velocidade do player
      velocity += gravity;
      position += velocity;
      updatePlayer(player);
      
      // Criar o bouding box para o zubat
      var box = document.getElementById('jogador').getBoundingClientRect();
      var origwidth = 38.0;
      var origheight = 25.0;
      
      var boxwidth = origwidth - (Math.sin(Math.abs(rotation) / 90) * 8);
      var boxheight = (origheight + box.height) / 2;
      var boxleft = ((box.width - boxwidth) / 2) + box.left;
      var boxtop = ((box.height - boxheight) / 2) + box.top;
      var boxright = boxleft + boxwidth;
      var boxbottom = boxtop + boxheight;
     
      // Se acertar o chão, o jogador morre, bundão
      if(box.bottom >= $("#chao").offset().top) {
         playerDead();
         return;
      }
      
      // Se tentar passar pelo topo, zera a posição e nada acontecerá
      var crustle = $("#crustle");
      if(boxtop <= (crustle.offset().top + crustle.height()))
         position = 0;
      
      // Se não houver nenhum cano no jogo retorna
      if(pipes[0] === null)
         return;
      
      // Determina a área para os próximos canos
      var nextpipe = pipes[0];
      var nextpipeupper = nextpipe.children(".pipe_upper");
      
      var pipetop = nextpipeupper.offset().top + nextpipeupper.height();
      var pipeleft = nextpipeupper.offset().left; // Por algum motivo ele começa no deslocamento dos tubos internos
      var piperight = pipeleft + pipewidth;
      var pipebottom = pipetop + pipeheight;
      
      // O que acontece se cair dentro do tubo
      if(boxright > pipeleft) {
          if(boxtop > pipetop && boxbottom < pipebottom) {
           }
         else {
            playerDead();
            return;
         }
      }
      
      
     if(boxleft > piperight) {
         // se sim, remove e aparece outro
         pipes.splice(0, 1);
         
         // pontua a partir do momento que o pixel passa do cano
         playerScore();
      }
   }

   // Pulos pela barra de espaço
   $(document).keydown(function(e){
     
      if(e.keyCode == 32) {
           if(currentstate == states.ScoreScreen)
            $("#replay").click();
         else
            screenClick();
      }
   });
 
   // Usar o mouse ou o teclado para começar
   if("ontouchstart" in window)
      $(document).on("touchstart", screenClick);
   else
      $(document).on("mousedown", screenClick);

   function screenClick() {
      if(currentstate == states.GameScreen)
      {
         playerJump();
      }
      else if(currentstate == states.SplashScreen) {
         startGame();
      }
   }

   // Função para passar o pulo e o som
   function playerJump() {
      velocity = jump;
      // iniciar o som com o pulo
      soundJump.stop();
      soundJump.play();
   }

   // Função para adicionar os números ao longo do jogo
   function setBigScore(erase) {
      var elemscore = $("#bigscore");
      elemscore.empty();
      
      if(erase)
         return;
      
      var digits = score.toString().split('');
      for(var i = 0; i < digits.length; i++)
         elemscore.append("<img src='imagens/font_big_" + digits[i] + ".png' alt='" + digits[i] + "'>");
   }

   // Função para adicionar os números dos pnts na tela no fim do jogo
   function setSmallScore()   {
      var elemscore = $("#currentscore");
      elemscore.empty();
      
      var digits = score.toString().split('');
      for(var i = 0; i < digits.length; i++)
         elemscore.append("<img src='imagens/font_small_" + digits[i] + ".png' alt='" + digits[i] + "'>");
   }

   function setRecorde() {
      var elemscore = $("#recorde");
      elemscore.empty();
      
      var digits = recorde.toString().split('');
      for(var i = 0; i < digits.length; i++)
         elemscore.append("<img src='imagens/font_small_" + digits[i] + ".png' alt='" + digits[i] + "'>");
   }

   // Função para adicionar a medalha em função dos pontos
   function setMedal() {
      var elemmedal = $("#medal");
      elemmedal.empty();
      
      if(score < 10)
         return false;
      
      if(score >= 10)
         medal = "bronze";
      if(score >= 20)
         medal = "silver";
      if(score >= 30)
         medal = "gold";
      if(score >= 40)
         medal = "platinum";
      
      elemmedal.append('<img src="imagens/medal_' + medal +'.png" alt="' + medal +'">');
      return true;
   }
    function playerDead(){
      // Pausando todas as animações
      $(".animated").css('animation-play-state', 'paused');
      $(".animated").css('-webkit-animation-play-state', 'paused');
      
      // PArar o passarinho do chão
      var playerbottom = $("#jogador").position().top + $("#player").width(); // Usamos porque ele irá rotacionar 90º
      var floor = $("#area-executavel").height();
      var movey = Math.max(0, floor - playerbottom);
      $("#jogador").transition({ y: movey + 'px', rotate: 90}, 1000, 'easeInOutCubic');
      
      // Este é o tempo para mudar os estados.
      currentstate = states.ScoreScreen;

      // Destroi todos os games loops
      clearInterval(loopGame);
      clearInterval(loopPipe);
      loopGame = null;
      loopPipe = null;

      // Mobile browsers não suportam buzz bindOnce event
      if(isIncompatible.any()) {
         // Mostra o score
         showScore();
      }
      else{
         // Começa o hit sound e depois o som de morte e depois mostra o score
         soundHit.play().bindOnce("ended", function() {
            soundDie.play().bindOnce("ended", function() {
               showScore();
            });
         });
      }
   }

   // Função para mostrar o score
   function showScore() {
      // Mostra o quadro do score
      $("#scoreboard").css("display", "block");
      
      // Remove o big score da tela
      setBigScore(true);
      
      // Se o score obtido for maior que o maior score já obtido
      if(score > recorde){
         // Salva o score
         recorde = score;
         // Salva no cookie
         setCookie("recorde", recorde, 999);
      }
      
      // Muda o quadro de score
      setSmallScore();
      setRecorde();
      var wonmedal = setMedal();
      
      // som do swoosh
      soundSwoosh.stop();
      soundSwoosh.play();
      
      // Mostra o quadro de score
      $("#scoreboard").css({ y: '40px', opacity: 0 }); // Move o quadro de score para biaxo
      $("#replay").css({ y: '40px', opacity: 0 });
      $("#scoreboard").transition({ y: '0px', opacity: 1}, 600, 'ease', function() {
         // Qaundo a animação terminar começa o som de transição
         soundSwoosh.stop();
         soundSwoosh.play();
         $("#replay").transition({ y: '0px', opacity: 1}, 600, 'ease');
         
         // também animal a medalha para aparecer no quadro de score
         if(wonmedal){
            $("#medal").css({ scale: 2, opacity: 0 });
            $("#medal").transition({ opacity: 1, scale: 1 }, 1200, 'ease');
         }
      });
      
      // deixa o botão de replay com clique
      replayclickable = true;
   }

   $("#replay").click(function() {
      if(!replayclickable)
         return;
      else
         replayclickable = false;
      soundSwoosh.stop();
      soundSwoosh.play();
      
      // Fade para o quadro de score sumir
      $("#scoreboard").transition({ y: '-40px', opacity: 0}, 1000, 'ease', function() {
         // Esconde o quadro de score
         $("#scoreboard").css("display", "none");
         
         // começa o game over e mostra a splash screen
         showSplash();
      });
   });

   // Função para armazenar a pontuação do jogador
   function playerScore(){
      score += 1;
      soundScore.stop();
      soundScore.play();
      setBigScore();
   }

   // Função para ir mostrando e mudar os canos
   function updatePipes() {
      $(".pipe").filter(function() { return $(this).position().left <= -100; }).remove()
      
      // Add um novo cano (top height + bottom height  + pipeheight == 420) e coloca o cano em outra área
      var padding = 80;
      var constraint = 420 - pipeheight - (padding * 2); // duplicando a margem interna
      var topheight = Math.floor((Math.random()*constraint) + padding); // add padding abaixo
      var bottomheight = (420 - pipeheight) - topheight;
      var newpipe = $('<div class="pipe animated"><div class="pipe_upper" style="height: ' + topheight + 'px;"></div><div class="pipe_lower" style="height: ' + bottomheight + 'px;"></div></div>');
      $("#area-executavel").append(newpipe);
      pipes.push(newpipe);
   }


   // Definindo o suporte dos navegadores para o event Buzz definido anteriormente
   var isIncompatible = {
         Android: function() {
            return navigator.userAgent.match(/Android/i);
         },
         BlackBerry: function() {
             return navigator.userAgent.match(/BlackBerry/i);
         },
         iOS: function() {
              return navigator.userAgent.match(/iPhone|iPad|iPod/i);
         },
         Opera: function() {
              return navigator.userAgent.match(/Opera Mini/i);
         },
         Safari: function() {
              return (navigator.userAgent.match(/OS X.*Safari/) && ! navigator.userAgent.match(/Chrome/));
         },
         Windows: function() {
         return navigator.userAgent.match(/IEMobile/i);
         },
         any: function() {
              return (isIncompatible.Android() || isIncompatible.BlackBerry() || isIncompatible.iOS() || isIncompatible.Opera() || isIncompatible.Safari() || isIncompatible.Windows());
         }
   };